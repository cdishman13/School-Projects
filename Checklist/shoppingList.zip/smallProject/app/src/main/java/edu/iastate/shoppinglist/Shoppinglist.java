package edu.iastate.shoppinglist;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = Constants.TABLE_NAME_SHOPPINGLIST)
public class Shoppinglist implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private long shoppinglist_id;

    @ColumnInfo(name="shoppinglist_content")
    private String content;

    private String name;

    public Shoppinglist(String content, String name) {
        this.content = content;
        this.name = name;
    }

    @Ignore
    public Shoppinglist(){}

    public long getShoppinglist_id() {
        return shoppinglist_id;
    }

    public void setShoppinglist_id(long shoppinglist_id) {
        this.shoppinglist_id = shoppinglist_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if(this==o) return true;
        if(!(o instanceof Shoppinglist)) return false;
        Shoppinglist shoppinglist = (Shoppinglist) o;
        if(shoppinglist_id != shoppinglist.shoppinglist_id) return false;
        return name != null ? name.equals(shoppinglist.name) : shoppinglist.name==null;
    }

    @Override
    public int hashCode() {
        int result = (int) shoppinglist_id;
        result = 31 * result + (name!=null ? name.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Note{" +
                "note_id=" + shoppinglist_id +
                ", content='" + content + '\'' +
                ", title='" + name + '\'' +
                '}';
    }
}
