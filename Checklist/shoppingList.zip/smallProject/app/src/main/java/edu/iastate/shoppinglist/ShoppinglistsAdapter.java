package edu.iastate.shoppinglist;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ShoppinglistsAdapter extends RecyclerView.Adapter<ShoppinglistsAdapter.BeanHolder> {

    private List<Shoppinglist> list;
    private Context context;
    private LayoutInflater layoutInflater;
    private OnShoppinglistItemClick onShoppinglistItemClick;

    public ShoppinglistsAdapter(List<Shoppinglist> list, Context context) {
        layoutInflater = LayoutInflater.from(context);
        this.list = list;
        this.context = context;
        //this.onShoppinglistItemClick = (OnShoppinglistItemClick) context;
    }

    @Override
    public BeanHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.shoppinglist_list_item, parent, false);
        return new BeanHolder(view);
    }

    @Override
    public void onBindViewHolder(BeanHolder holder, int position) {
        Log.e("bind", "onBindViewHolder: " + list.get(position));
        holder.textViewName.setText(list.get(position).getName());
        holder.textViewContent.setText(list.get(position).getContent());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class BeanHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textViewContent;
        TextView textViewName;
        public BeanHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            textViewContent = itemView.findViewById(R.id.item_text);
            textViewName = itemView.findViewById(R.id.item_name);
        }

        @Override
        public void onClick(View view) {
            onShoppinglistItemClick.onShoppinglistClick(getAdapterPosition());
        }
    }

    public interface OnShoppinglistItemClick {
        void onShoppinglistClick(int pos);
    }

}
