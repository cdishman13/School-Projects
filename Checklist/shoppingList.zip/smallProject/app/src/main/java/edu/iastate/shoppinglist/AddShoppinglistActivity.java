package edu.iastate.shoppinglist;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.lang.ref.WeakReference;

public class AddShoppinglistActivity extends AppCompatActivity {

    private TextInputEditText et_name, et_content;
    private boolean update;

    private Shoppinglist shoppinglist;
    private ShoppinglistDatabase shoppinglistDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_shoppinglist);
        et_name = findViewById(R.id.et_name);
        et_content = findViewById(R.id.et_content);
        shoppinglistDatabase = ShoppinglistDatabase.getInstance(AddShoppinglistActivity.this);
        Button button = findViewById(R.id.but_save);
        if ( (shoppinglist = (Shoppinglist) getIntent().getSerializableExtra("shoppinglist"))!=null ){
            getSupportActionBar().setTitle("Update Shoppinglist");
            update = true;
            button.setText("Update");
            et_name.setText(shoppinglist.getName());
            et_content.setText(shoppinglist.getContent());
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (update){
                    shoppinglist.setContent(et_content.getText().toString());
                    shoppinglist.setName(et_name.getText().toString());
                    shoppinglistDatabase.getShoppinglistDao().updateShoppinglist(shoppinglist);
                    setResult(shoppinglist,2);
                }else {
                    shoppinglist = new Shoppinglist(et_content.getText().toString(), et_name.getText().toString());
                    new InsertTask(AddShoppinglistActivity.this,shoppinglist).execute();
                }
            }
        });
    }

    private void setResult(Shoppinglist shoppinglist, int flag){
        setResult(flag,new Intent().putExtra("shoppinglist",shoppinglist));
        finish();
    }

    private static class InsertTask extends AsyncTask<Void,Void,Boolean> {

        private WeakReference<AddShoppinglistActivity> activityReference;
        private Shoppinglist shoppinglist;

        // only retain a weak reference to the activity
        InsertTask(AddShoppinglistActivity context, Shoppinglist shoppinglist) {
            activityReference = new WeakReference<>(context);
            this.shoppinglist = shoppinglist;
        }

        // doInBackground methods runs on a worker thread
        @Override
        protected Boolean doInBackground(Void... objs) {
            // retrieve auto incremented note id
            long j = activityReference.get().shoppinglistDatabase.getShoppinglistDao().insertShoppingList(shoppinglist);
            shoppinglist.setShoppinglist_id(j);
            Log.e("ID ", "doInBackground: "+j );
            return true;
        }

        // onPostExecute runs on main thread
        @Override
        protected void onPostExecute(Boolean bool) {
            if (bool){
                activityReference.get().setResult(shoppinglist,1);
                activityReference.get().finish();
            }
        }
    }

}
