package edu.iastate.shoppinglist;

final public class Constants {
    private Constants() {}
    public static final String TABLE_NAME_SHOPPINGLIST="shoppinglists";
    public static final String DB_NAME="shoppinglistsdb.db";
}
