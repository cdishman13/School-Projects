package edu.iastate.shoppinglist;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities={Shoppinglist.class}, version = 1)
public abstract class ShoppinglistDatabase extends RoomDatabase {

    public abstract ShoppinglistDao getShoppinglistDao();

    private static ShoppinglistDatabase shoppinglistDB;

    public static ShoppinglistDatabase getInstance(Context context) {
        if(shoppinglistDB==null)
            shoppinglistDB = buildDatabaseInstance(context);
        return shoppinglistDB;
    }

    private static ShoppinglistDatabase buildDatabaseInstance(Context context) {
        return Room.databaseBuilder(context, ShoppinglistDatabase.class, Constants.DB_NAME).allowMainThreadQueries().build();
    }

    public void cleanUp(){
        shoppinglistDB = null;
    }

}
