package edu.iastate.shoppinglist;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShoppinglistDao {

    @Query("SELECT * FROM + Constants.TABLE_NAME_SHOPPINGLIST")
    List<Shoppinglist> getShoppinglists();

    @Insert
    long insertShoppingList(Shoppinglist shoppinglist);

    @Update
    void updateShoppinglist(Shoppinglist repos);

    @Delete
    void deleteShoppinglist(Shoppinglist shoppinglist);

    @Delete
    void deleteShoppinglists(Shoppinglist... shoppinglist);

}
