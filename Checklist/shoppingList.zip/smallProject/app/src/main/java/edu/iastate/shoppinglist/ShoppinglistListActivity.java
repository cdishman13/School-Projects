package edu.iastate.shoppinglist;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class ShoppinglistListActivity extends AppCompatActivity implements ShoppinglistsAdapter.OnShoppinglistItemClick {

    private TextView textViewMsg;
    private RecyclerView recyclerView;
    private int pos;

    private ShoppinglistDatabase shoppinglistDatabase;
    private ShoppinglistsAdapter shoppinglistsAdapter;
    private List<Shoppinglist> shoppinglists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayList();
    }

    private void displayList() {
        shoppinglistDatabase = ShoppinglistDatabase.getInstance(ShoppinglistListActivity.this);
        new RetrieveTask(this).execute();
    }

    private static class RetrieveTask extends AsyncTask<Void,Void,List<Shoppinglist>> {
        private WeakReference<ShoppinglistListActivity> activityReference;

        RetrieveTask(ShoppinglistListActivity context) {
            activityReference = new WeakReference<>(context);
        }

        @Override
        protected List<Shoppinglist> doInBackground(Void... voids) {
            if(activityReference.get() != null)
                return activityReference.get().shoppinglistDatabase.getShoppinglistDao().getShoppinglists();
            else
                return null;
        }

        @Override
        protected void onPostExecute(List<Shoppinglist> shoppinglists) {
            if(shoppinglists != null && shoppinglists.size()>0) {
                activityReference.get().shoppinglists.clear();
                activityReference.get().shoppinglists.addAll(shoppinglists);
                activityReference.get().textViewMsg.setVisibility(View.GONE);
                activityReference.get().shoppinglistsAdapter.notifyDataSetChanged();
            }
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void initializeViews() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        textViewMsg =  (TextView) findViewById(R.id.name_empty);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(listener);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(ShoppinglistListActivity.this));
        shoppinglists = new ArrayList<>();
        shoppinglistsAdapter = new ShoppinglistsAdapter(shoppinglists,ShoppinglistListActivity.this);
        recyclerView.setAdapter(shoppinglistsAdapter);
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            startActivityForResult(new Intent(ShoppinglistListActivity.this,AddShoppinglistActivity.class),100);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode > 0) {
            if (resultCode == 1) {
                shoppinglists.add((Shoppinglist) data.getSerializableExtra("note"));
            } else if (resultCode == 2) {
                shoppinglists.set(pos, (Shoppinglist) data.getSerializableExtra("note"));
            }
            listVisibility();
        }
    }

    @Override
    public void onShoppinglistClick(final int pos) {
        new AlertDialog.Builder(ShoppinglistListActivity.this)
                .setTitle("Select Options")
                .setItems(new String[]{"Delete", "Update"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i){
                            case 0:
                                shoppinglistDatabase.getShoppinglistDao().deleteShoppinglist(shoppinglists.get(pos));
                                shoppinglists.remove(pos);
                                listVisibility();
                                break;
                            case 1:
                                ShoppinglistListActivity.this.pos = pos;
                                startActivityForResult(
                                        new Intent(ShoppinglistListActivity.this,
                                                AddShoppinglistActivity.class).putExtra("shoppinglist",shoppinglists.get(pos)),
                                        100);

                                break;
                        }
                    }
                }).show();

    }

    private void listVisibility(){
        int emptyMsgVisibility = View.GONE;
        if (shoppinglists.size() == 0){ // no item to display
            if (textViewMsg.getVisibility() == View.GONE)
                emptyMsgVisibility = View.VISIBLE;
        }
        textViewMsg.setVisibility(emptyMsgVisibility);
        shoppinglistsAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        shoppinglistDatabase.cleanUp();
        super.onDestroy();
    }


}
